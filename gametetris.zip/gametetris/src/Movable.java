public interface Movable {
    void dropPiece();

    void movePieceLeft();

    void movePieceRight();

    void rotatePiece();
}
